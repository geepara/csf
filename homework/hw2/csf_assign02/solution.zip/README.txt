George Paragioudakis
gparagi1@jh.edu
gparagi1

I worked on this alone.